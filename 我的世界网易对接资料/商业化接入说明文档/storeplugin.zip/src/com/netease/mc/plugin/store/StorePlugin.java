package com.netease.mc.plugin.store;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public class StorePlugin extends JavaPlugin {

  @Override
  public void onDisable() {}

  @Override
  public void onEnable() {
    Bukkit.getMessenger().registerOutgoingPluginChannel(this, "storemod");
    Bukkit.getMessenger().registerIncomingPluginChannel(this, "storemod",
        new StoreMessageListener());

  }
}
