package com.netease.mc.plugin.store;

import org.bukkit.entity.Player;
import org.bukkit.plugin.messaging.PluginMessageListener;

public class StoreMessageListener implements PluginMessageListener {

  @Override
  public void onPluginMessageReceived(String channel, Player player, byte[] message) {

    System.out.println("onStoreMessageReceived:" + channel + ", " + player.getName());
  }

}
